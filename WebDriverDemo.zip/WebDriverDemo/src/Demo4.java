import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
public class Demo4 {
	@Test	
	public void hello()
	{
		System.out.println("hello");
	}
@Test
public void testMethod() {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("D://SeleniumCEP//DemoHTML//Home.html");
		WebElement l=driver.findElement(By.partialLinkText("Log"));
		l.click();
		driver.findElement(By.name("uname")).sendKeys("Manisha");
		driver.findElement(By.name("pwd")).sendKeys("Syntel123$");
		driver.findElement(By.name("btnSbt")).click();
		Alert alert=driver.switchTo().alert();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		alert.accept();	
		driver.navigate().to("D://SeleniumCEP//DemoHTML//success.html");
		
//		String a=driver.getCurrentUrl();
//		String b="file:///D://SeleniumCEP//DemoHTML//success1.html";
//		assertEquals(a, b);
		
		
//		
		
		
		

	}

}
