import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
public class Demo7 {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///D:/SeleniumCEP/DemoHTML/Home.html");
		WebElement l=driver.findElement(By.partialLinkText("Log"));        
		// Configure the Action 
         Actions builder = new Actions(driver);
         System.out.println("before action");
         System.out.println(driver.getCurrentUrl());            		 

      // To click on the element
         Action act= builder.moveToElement(l).click().build();//registration
         Thread.sleep(500);
          act.perform();//execution
          
         System.out.println("after action");
         System.out.println(driver.getCurrentUrl());
         
        //multiplevent
       WebElement t=driver.findElement(By.name("uname"));
     //   t.sendKeys("Manisha");
        Action typ=builder
        .moveToElement(t)        		
        		.keyUp(t, Keys.SHIFT)//uppercase
        		.sendKeys("Manisha")//set value
        		.doubleClick(t)//higlight
        		.build();
      typ.perform();
         
       //  
        
       

		
	}

}
