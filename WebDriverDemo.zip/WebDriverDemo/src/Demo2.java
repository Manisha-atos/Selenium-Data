import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class Demo2 {

	public static void main(String[] args) {
//		FirefoxDriver driver =new FirefoxDriver();
//		driver.manage().window().maximize();
//		driver.get("http:\\www.google.com");
//		WebElement txtSearch=driver.findElement(By.name("q"));
//		txtSearch.sendKeys("flowers");
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://www.google.com");
		driver.manage().window().maximize();
		System.out.println("current URL: "+driver.getCurrentUrl());
		driver.navigate().to("https://webapp2.syntelinc.com");
		System.out.println("current URL: "+driver.getCurrentUrl());
		driver.navigate().back();
		System.out.println();
//		driver = new ChromeDriver();
//		driver.get("http://www.google.com");
//		driver.manage().window().maximize();
//		WebElement u=driver.findElement(By.id("lst-ib"));
//		u.sendKeys("flowers images");
//		driver.findElement(By.name("btnK")).click();
//		
//		WebElement l=driver.findElement(By.linkText("Images"));
//		l.click();
//		
//		System.out.println("end");

	}

}
