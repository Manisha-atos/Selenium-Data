import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class Demo10 {
	public static void handlePopup(WebDriver driver)
		{
		String MainWindow=driver.getWindowHandle();		
		
        // To handle all new opened window.				
            Set<String> s1=driver.getWindowHandles();		
        Iterator<String> i1=s1.iterator();		
        		
        while(i1.hasNext())			
        {		
            String ChildWindow=i1.next();		
            		
            if(!MainWindow.equalsIgnoreCase(ChildWindow))			
            {    		
                 
                    // Switching to Child window
                    driver.switchTo().window(ChildWindow);	                                                                                                           
                    driver.findElement(By.name("emailid"))
                    .sendKeys("gaurav.3n@gmail.com");                			
                    
                    driver.findElement(By.name("btnLogin")).click();			
                                 
			// Closing the Child Window.
                        driver.close();		
            }		
        }		
        // Switching to Parent window i.e Main Window.
            driver.switchTo().window(MainWindow);	
	}
	
public static void main(String[] args) {
		// TODO Auto-generated method stub
WebDriver driver;
System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
driver = new ChromeDriver();
//Demo10.handlePopup(driver);
driver.get("https://www.calculatorsoup.com");

WebElement l=driver.findElement(By.linkText("Loans"));
l.click();
WebElement u=driver.findElement(By.partialLinkText("Advanced Loan Ca"));
u.click();
//driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;

//Alert alert=driver.switchTo().alert();
//alert.accept();
Select d1=new Select(driver.findElement(By.name("given_data")));
d1.selectByIndex(1);


WebElement amt=driver.findElement(By.xpath(".//*[@id='pv']"));
amt.clear();
amt.sendKeys("200000");

//WebElement rate=driver.findElement(By.id("ratepercent"));
//rate.sendKeys("1234.55");

Select d2=new Select(driver.findElement(By.name("m")));
d1.selectByIndex(1);

WebElement tot=driver.findElement(By.id("nper"));
tot.clear();
tot.sendKeys("50");

Select d3=new Select(driver.findElement(By.name("q")));
d1.selectByIndex(1);

WebElement btn=driver.findElement(By.xpath(".//*[@id='actionCalculate']/input"));
btn.click();


	}

}
