import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Demo1 {

	public static void main(String[] args) {
		//FirefoxDriver driver =new FirefoxDriver();
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http:\\www.google.com");
		System.out.println("current URL: "+driver.getCurrentUrl());
		driver.navigate().to("https://webapp2.syntelinc.com");
		String URL = driver.getCurrentUrl();
		System.out.println("URL Is: "+ URL);
		driver.navigate().back();
		System.out.println("current URL: "+driver.getCurrentUrl());
		driver.navigate().forward();
		System.out.println("current URL: "+driver.getCurrentUrl());
		driver.close();

	}

}
