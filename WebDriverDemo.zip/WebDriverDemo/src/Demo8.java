import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Demo8 {
	public static void main(String ar[]) throws InterruptedException
	{
//		Simple Alert Demo		
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("file:///D:/SeleniumCEP/DemoHTML/Home.html");
	WebElement l=driver.findElement(By.partialLinkText("Log"));
	l.click();
	driver.findElement(By.name("uname")).sendKeys("Manisha");
	driver.findElement(By.name("pwd")).sendKeys("Syntel123$");
	driver.findElement(By.name("btnSbt")).click();
	Alert alert=driver.switchTo().alert();
	Thread.sleep(5000);
	alert.accept();	
	
	//Confirmation Alert
	driver.findElement(By.partialLinkText("want ")).click();
	driver.findElement(By.name("eid")).sendKeys("MK50421321");
	driver.findElement(By.name("cmpBtn")).click();
	
	String msg=alert.getText();
	System.out.println(msg);
	Thread.sleep(5000);
	alert.dismiss();	
	
	driver.navigate().to("file:///D:/SeleniumCEP/DemoHTML/search.html");
	driver.findElement(By.name("prmBtn")).click();
	//Switch the control of 'driver' to the Alert from main 
	alert=driver.switchTo().alert();
	Thread.sleep(5000);
	alert.sendKeys("sam");
	System.out.println("Welcome "+alert.getText());
	alert.accept();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MINUTES);
	WebDriverWait wait = new WebDriverWait(driver, 10);
	//wait.until(ExpectedConditions.elementToBeClickable(By.i));

	
	
	}
}
