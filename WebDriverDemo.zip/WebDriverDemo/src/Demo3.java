import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
public class Demo3 {
public static void main(String ar[])
{
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
	driver = new ChromeDriver();
//	FirefoxDriver driver=new FirefoxDriver();
	driver.get("http://www.calculator.net");
	//driver.manage().window().maximize();
	WebElement u=driver.findElement(By.partialLinkText("Loan Ca"));
	u.click();
	//driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
	WebElement amt=driver.findElement(By.id("cloanamount"));
	
	amt.clear();
	amt.sendKeys("200000");
	
	Select mntDD=new Select(driver.findElement(By.name("ccompound")));
	//mntDD.selectByValue("Weekly");
	mntDD.selectByVisibleText("Weekly");	
	
	Select pbDD=new Select(driver.findElement(By.name("cpayback")));
	pbDD.selectByIndex(2);
	
	WebElement btn=driver.findElement(By.xpath(".//*[@id='calinputtable']/tbody/tr[7]/td/input"));
	btn.click();
	
	System.out.println(driver.findElement(By.xpath(".//*[@id='calinputtable']/tbody/tr[7]/td/input")).getText());
	driver.close();
	System.out.println("end");
	
}
}
