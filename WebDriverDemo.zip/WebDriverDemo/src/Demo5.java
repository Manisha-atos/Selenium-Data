import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class Demo5 {
	public static void main(String[] args) {
		System.out.println("welcome");
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("D://SeleniumCEP//DemoHTML//Home.html");
		WebElement l=driver.findElement(By.partialLinkText("Reg"));
		String name=l.getText();
		System.out.println("text"+name);
		l.click();
		WebElement u=driver.findElement(By.name("uname"));
		u.sendKeys("admin");
		
		WebElement p=driver.findElement(By.name("pwd"));
		p.sendKeys("Syntel123$");
		
		WebElement c=driver.findElement(By.id("col-3"));
		c.click();
		System.out.println(c.isSelected());
		String txt=driver.findElement(By.id("col-3")).getText();
		System.out.println("txt"+txt);
		
		WebElement ln=driver.findElement(By.id("lang-2"));
		ln.click();
		
		WebElement ln1=driver.findElement(By.id("lang-3"));
		ln1.click();
		
		Select age = new Select(driver.findElement(By.name("sltAge")));
		age.selectByIndex(3);
		
		//Multiple selection
		Select loc = new Select(driver.findElement(By.name("sltLoc")));
		loc.selectByVisibleText("Mumbai");
		loc.selectByIndex(1);
			
		
		Select gen = new Select(driver.findElement(By.name("sltgen")));
		gen.selectByValue("F");
		
		//Datetimepicker
		
		WebElement dateBox=driver.findElement(By.name("bdaytime"));
		//Fill date as mm/dd/yyyy as 09/25/2013

        dateBox.sendKeys("09252013");

        //Press tab to shift focus to time field

        dateBox.sendKeys(Keys.TAB);

        //Fill time as 02:45 PM

        dateBox.sendKeys("0245PM");

				
		

	}

}
