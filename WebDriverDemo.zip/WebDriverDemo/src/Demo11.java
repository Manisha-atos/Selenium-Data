import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo11 {

	public static void main(String[] args) {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///D:/SeleniumCEP/DemoHTML/Login1.html");
		
driver.findElement(By.name("uname")).sendKeys("Manisha");
//driver.findElement(By.name("btnLogin")).click();
driver.findElement(By.name("pwd")).sendKeys(driver.findElement(By.name("uname")).getText());


	}

}
