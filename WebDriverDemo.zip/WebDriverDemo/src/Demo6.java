
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Demo6 {

	public static void main(String[] args) {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///D:/SeleniumCEP/DemoHTML/Table.html");
		WebElement t=driver.findElement(By.name("detail"));
		//code to minimize the window as there is no minimize method in selenium
	//	driver.manage().window().setPosition(new Point(-2000, 0));
		//driver.manage().window()
		List  col = driver.findElements(By.xpath("html/body/table/tbody/tr[1]/th"));
		
System.out.println(col.size());

List  row = driver.findElements(By.xpath("html/body/table/tbody/tr"));

System.out.println(row.size()-1);

WebElement cell=driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[1]"));
System.out.println(cell.getText());
System.out.println("Table Data");
for(int i=1;i<=row.size()-1;i++)
{
	for(int j=1;j<=col.size();j++ )
	{
		WebElement td=driver.findElement(By.xpath("html/body/table/tbody/tr["+(i+1)+"]/td["+j+"]"));
		System.out.print(td.getText());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	System.out.println();
}

	}

}
