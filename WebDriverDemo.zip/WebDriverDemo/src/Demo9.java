import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
public class Demo9 {
	public static void main(String[] args) {
		//FirefoxDriver driver=new FirefoxDriver();
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);		
		driver.get("http://www.calculator.net");
		driver.findElement(By.partialLinkText("Loan ")).click();
		WebElement amt= driver.findElement(By.id("cloanamount"));
		amt.sendKeys("124582");
		
		WebElement term= driver.findElement(By.id("cloanterm"));
		amt.sendKeys("12");
		
	
		WebElement rate= driver.findElement(By.id("	cinterestrate"));
		amt.sendKeys("7");
		
		Select d1=new Select(driver.findElement(By.id("ccompound")));
		d1.selectByValue("Daily");
		
		WebElement btn=driver.findElement(By.xpath(".//*[@id='calinputtable']/tbody/tr[7]/td/input"));
		btn.click();
		
		WebElement tint=driver.findElement(By.xpath(".//*[@id='content']/table[1]/tbody/tr/td[2]/table/tbody/tr[3]/td[2]/b"));
		System.out.println(tint.getText());
		
	}
}
